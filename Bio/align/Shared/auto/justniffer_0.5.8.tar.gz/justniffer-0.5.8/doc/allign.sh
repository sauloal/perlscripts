#!/bin/bash
scp  web/* onotelli,justniffer@web.sourceforge.net:/home/groups/j/ju/justniffer/htdocs/
